package com.cognizant.junit_setup;

public class MathOperations {

    public int add(int a, int b) {
        return a + b;
    }

    public int square(int x) {
        return x * x;
    }

    public boolean isEven(int number) {
        return number % 2 == 0;
    }
}
