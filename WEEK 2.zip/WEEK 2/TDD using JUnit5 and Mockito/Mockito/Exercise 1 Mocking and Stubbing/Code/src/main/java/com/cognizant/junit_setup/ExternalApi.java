package com.cognizant.junit_setup;

public interface ExternalApi {
    String getData();
}